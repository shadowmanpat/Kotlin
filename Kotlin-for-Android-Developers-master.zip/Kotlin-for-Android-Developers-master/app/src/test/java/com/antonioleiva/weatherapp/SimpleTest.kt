package com.antonioleiva.weatherapp

import org.junit.Assert.assertTrue
import org.junit.Test

class SimpleTest {

    @Test fun unitTestingWorks() {
        assertTrue(true)
    }
}